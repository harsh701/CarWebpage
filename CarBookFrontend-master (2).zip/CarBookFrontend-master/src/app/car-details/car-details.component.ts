import { Component, OnInit } from '@angular/core';
import { apiService } from '../../Service/apiService'

@Component({
  selector: 'app-car-details',
  templateUrl: './car-details.component.html',
  styleUrls: ['./car-details.component.scss']
})
export class CarDetailsComponent implements OnInit {

  constructor(private apis: apiService) { }
  carId = localStorage.getItem("id");
  Detail;
  ngOnInit() {
    this.carDetail()
  }

  carDetail() {
    console.log("id", this.carId)
    this.apis.get("cars/" + this.carId).subscribe(res => {
      console.log("car", res)
      this.Detail = res;
    })

  }
}
