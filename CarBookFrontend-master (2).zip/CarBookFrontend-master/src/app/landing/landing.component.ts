import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

import { apiService } from '../../Service/apiService'
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {
  carForm: FormGroup;
  registerUserForm: FormGroup;
  searchForm: FormGroup;
  loginForm: FormGroup;
  listCar: any;
  filesizeerror
  typeerror
  imgURLMain;
  imgURLSecond;
  imgURLThird;
  formData
  file
  message = "";
  status = false;
  searchCarOBj = {
    name
  }
  constructor(private apis: apiService, private router: Router, ) { }

  ngOnInit() {
    this.carForm = new FormGroup({
      company: new FormControl(),
      name: new FormControl(),
      model: new FormControl(),
      milage: new FormControl(),
      color: new FormControl(),
      price: new FormControl(),
      city: new FormControl(),
      image: new FormControl(),
      contactNumber: new FormControl()

    })

    this.registerUserForm = new FormGroup({
      firstName: new FormControl(),
      lastName: new FormControl(),
      email: new FormControl(),
      city: new FormControl(),
      password: new FormControl(),



    })
    this.loginForm = new FormGroup({

      email: new FormControl(),
      password: new FormControl(),



    })

    this.searchForm = new FormGroup({

      name: new FormControl(),




    })
    this.listOfCar();
  }
  searchCar() {
    console.log("val", this.searchCarOBj)
    this.apis.post("cars/searchCar", this.searchCarOBj).subscribe(res => {
      console.log("car", res)


      this.listCar = res;

      if (this.listCar.length == 0) {
        console.log("no record")
        document.getElementById('openModel').click();
        //alert("No Record Found")
      }

    })
  }
  onFileChangedMain(event: any) {
    if (event && event.target.files.length > 0) {

      this.file = event.target.files[0];
      console.log(this.file);
      console.log('filesize', this.file.size / 1000000);
      const filesize = this.file.size / 1000000;
      const type = this.file.type;
      if (filesize <= 5 && (type === 'image/jpeg' || type === 'image/png')) {
        this.filesizeerror = false;

        console.log('true');
        this.formData = new FormData();
        this.formData.append('file', this.file, this.file.name);
        const reader = new FileReader();
        reader.onload = (value: any) => {
          this.imgURLMain = value.target.result;
        }
        reader.readAsDataURL(event.target.files[0]);

        this.apis.post("cars/fileUpload", this.formData).subscribe(res => {
          console.log("res of imge", res)

          localStorage.setItem("firstImageMain", res.toString())
        })



      } else if (filesize > 5) {
        console.log('false');
        this.filesizeerror = true;
        this.typeerror = false;
      } else if (type !== 'image/png' || 'image/jpeg') {
        this.typeerror = true;
        this.filesizeerror = false;
      }
    }

  }

  onFileChangedSecond(event: any) {
    if (event && event.target.files.length > 0) {

      this.file = event.target.files[0];
      console.log(this.file);
      console.log('filesize', this.file.size / 1000000);
      const filesize = this.file.size / 1000000;
      const type = this.file.type;
      if (filesize <= 5 && (type === 'image/jpeg' || type === 'image/png')) {
        this.filesizeerror = false;

        console.log('true');
        this.formData = new FormData();
        this.formData.append('file', this.file, this.file.name);
        const reader = new FileReader();
        reader.onload = (value: any) => {
          this.imgURLSecond = value.target.result;
        }
        reader.readAsDataURL(event.target.files[0]);

        this.apis.post("cars/fileUpload", this.formData).subscribe(res => {
          console.log("res of imge", res)

          localStorage.setItem("firstImageSecond", res.toString())
        })



      } else if (filesize > 5) {
        console.log('false');
        this.filesizeerror = true;
        this.typeerror = false;
      } else if (type !== 'image/png' || 'image/jpeg') {
        this.typeerror = true;
        this.filesizeerror = false;
      }
    }

  }

  onFileChangedThird(event: any) {
    if (event && event.target.files.length > 0) {

      this.file = event.target.files[0];
      console.log(this.file);
      console.log('filesize', this.file.size / 1000000);
      const filesize = this.file.size / 1000000;
      const type = this.file.type;
      if (filesize <= 5 && (type === 'image/jpeg' || type === 'image/png')) {
        this.filesizeerror = false;

        console.log('true');
        this.formData = new FormData();
        this.formData.append('file', this.file, this.file.name);
        const reader = new FileReader();
        reader.onload = (value: any) => {
          this.imgURLThird = value.target.result;
        }
        reader.readAsDataURL(event.target.files[0]);

        this.apis.post("cars/fileUpload", this.formData).subscribe(res => {
          console.log("res of imge", res)

          localStorage.setItem("firstImageThird", res.toString())
        })



      } else if (filesize > 5) {
        console.log('false');
        this.filesizeerror = true;
        this.typeerror = false;
      } else if (type !== 'image/png' || 'image/jpeg') {
        this.typeerror = true;
        this.filesizeerror = false;
      }
    }

  }
  listOfCar() {

    this.apis.get("cars").subscribe(res => {

      this.listCar = res
      console.log("list of car", this.listCar)
    })
  }
  registerCar(val) {
    console.log(localStorage.getItem("firstImageMain")),
      console.log(localStorage.getItem("firstImageSecond")),
      console.log(localStorage.getItem("firstImageThird"))

    let registerCarObj = {
      company: val.company,
      name: val.name,
      model: val.model,
      milage: val.milage,
      color: val.color,
      price: val.price,
      city: val.city,
      contactNumber: val.contactNumber,
      MainImage: localStorage.getItem("firstImageMain"),
      SecondImage: localStorage.getItem("firstImageSecond"),
      ThirdImage: localStorage.getItem("firstImageThird")

    }

    console.log("ca", registerCarObj)

    this.message = "Your ads submitted Thanks"
    this.apis.post("cars", registerCarObj).subscribe(res => {
      console.log("car added");



    })
    this.listOfCar()
    location.reload();
  }
  registerUser(val) {
    console.log("value", val)
    let registerUser = val
    this.apis.post("users", registerUser).subscribe(res => {
      this.message = "Your Successfully Register with us"
      console.log("user added")
    })

  }
  viewDetail(id) {
    console.log("id", id)
    //routerLink="/details"
    localStorage.removeItem("id")

    localStorage.setItem("id", id)
    this.router.navigate(['details']);


  }
  login(val) {
    this.apis.post("users/login", val).subscribe(res => {
      console.log("login", res)

      if (res) {
        document.getElementById('close').click();
        this.status = true;

      }
      else {
        this.message = "Your UserName or Password Invalid"
      }

    })
  }
  logout() {
    this.status = false;
  }
}
